RESI letterhead for LaTeX

Compile main.tex with pdfLaTeX, XeLaTeX, or LuaLaTeX. Keep the images folder alongside main.tex.

Replace the \null line with your letter. The header repeats on each page. US Letter paper, one-inch side margins, no footer. The logo and typography are embedded, so no additional font installation is required.
